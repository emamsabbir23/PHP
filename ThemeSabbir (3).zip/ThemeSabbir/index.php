<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <link rel="stylesheet" href="<?= get_stylesheet_uri();?>">
    <link rel="stylesheet" href="<?= get_template_directory_uri()?>.'/Assets/CSS/bootstrap.min.css'">
<?php wp_head(); ?>
</head>
<body>
    <!-- Header Part Start -->
    <header class="cont">
        <div class="row topbar">
            <div class="col-lg-6 header_left">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 header_right text-end">
                <p>২১ কার্তিক, ১৪২৯</p>
                <a href="#">English</a>
            </div>
        </div>        
    </header>
    <!-- Header Part End -->
    <!-- Logo Part Start -->
    <section class="cont">
        <div class="row logo">
            <div class="col-lg-5 logo_left">
                <a href="#">
                    <?php the_custom_logo(); ?>
                    <img src="./Assets/Images/Header/logo_bn.png" alt="">
                </a>
            </div>
            <div class="col-lg-5 logo_search">
                <form action="">
                    <input type="text" placeholder="খুঁজুন">
                    <button><b>অনুসন্ধান</b></button>
                </form>
            </div>
            <div class="col-lg-2 logo_right">
                <div class="logo1">
                    <a href="#">
                        <img src="./Assets/Images/Header/a2i-logo-footer.png" alt="">
                    </a>
                </div>
                <div class="logo2">
                    <h6><b>সাথে থাকুন:</b></h6>
                    <a href="#">
                        <img src="./Assets/Images/Header/facebook-icon.png" alt="">
                    </a>
                    <a href="#">
                        <img src="./Assets/Images/Header/twitter-blue-icon.png" alt="">
                    </a>
                    <a href="#">
                        <img src="./Assets/Images/Header/youtube-icon.png" alt="">
                    </a>
                    <a href="#">
                        <img src="./Assets/Images/Header/gplus-icon.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Logo Part End -->
    <!-- Menu Part Start -->
    <section class="cont">
        <div class="row main_menu">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">

                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <?php wp_nav_menu([
                      'menu_location'=>'Top_menu',
                      'menu_class'=>'navbar-nav top_menu nav-item'
                    ]); ?>
                   <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">হোম</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">বাংলাদেশ সম্পর্কিত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ই-সেবাসমূহ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাখাত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#"> বৈদেশিক বিনিয়োগ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">আইন-বিধি</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">তথ্য বাতায়ন</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাকুঞ্জ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ফরমস</a>
                      </li>
                    </ul> -->
                  </div>
                </div>
              </nav>
        </div>
    </section>
    <!-- Menu Part End -->
    <!-- Hero Part Start -->
    <section class="cont">
      <div class="row hero">
        <div class="hero_main col-lg-8">
          <div class="banner">
            <a href="#">
              <?php dynamic_sidebar('banner') ?>
              <img src="./Assets/Images/padmabanner.jpg" class="d-block w-100" alt="">
          </a>
          </div>
          <!-- Slider Part Start -->
          <div class="slider">
            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
              <?php $qry = new WP_query([
                'post_type'=>'post',
                'category_name'=>'Slider'
              ]); ?>
              <div class="carousel-inner">
                <?php
                $x=0;
                while($qry->have_posts()){$qry->the_post();
                $x++;
                ?>
                <div class="carousel-item <?= ($x==1)?'active':''?> ">
                  <?php the_post_thumbnail(); ?>
                  <!-- <img src="./Assets/Images/Slider/0.jpg" class="d-block w-100" alt="..."> -->
                </div>
                <?php } ?>
                <!-- <div class="carousel-item">
                  <img src="./Assets/Images/Slider/Banner-1.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./Assets/Images/Slider/banner-renew-your-passport.png" class="d-block w-100" alt="...">
                </div> -->

              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
          <!-- Slider Part End -->
          <!-- Tab Part Start -->
          <div class="tab">
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">সকল ই-সেবা</button>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">Page Under The Constraction</div>
              <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">Page Under The Constraction</div>
              <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
              <?php $qry2 = new WP_query([
                'post_type'=>'post',
                'category_name'=>'জনপ্রিয় সেবা'
              ]); ?>
                <div class="row">
                <?php

                while($qry2->have_posts()){$qry2->the_post();

                ?>

                  <div class="col-lg-2 text-center">
                  <?php the_post_thumbnail(); ?>

                    <!-- <a href="#"><img src="./Assets/Images/Tab/agriculture.png" alt=""></a> -->
                    <p><?php the_title();?></p>
                  </div>
                  <?php } ?>
                  <!-- <div class="col-lg-2 text-center">
                    <a href="#"><img src="./Assets/Images/Tab/call_center.png" alt=""></a>
                    <p>কল সেন্টার</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./Assets/Images/Tab/helpdesk.png" alt=""></a>
                    <p>হেল্পডেস্ক</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./Assets/Images/Tab/mobile_service.png" alt=""></a>
                    <p>মোবাইল সেবা</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./Assets/Images/Tab/agriculture.png" alt=""></a>
                    <p>মৎস্য ও প্রাণী</p>
                  </div> -->
                </div>
              </div>
              <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">Page Under The Constraction</div>
            </div>
          </div>
          <!-- Tab Part End -->
          <div class="list">
            <h1>উদ্যোগ</h1>
            <ul>
              <li><a href="#">
                <?php dynamic_sidebar('list') ?>
                <!-- উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬) -->
              </a></li>
              <!-- <li><a href="#">উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬)</a></li>
              <li><a href="#">উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬)</a></li>
              <li><a href="#">উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬)</a></li>
              <li><a href="#">উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬)</a></li>
              <li><a href="#">উদ্যোগ
                বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) (১৩-০৬-২০১৬)</a></li> -->
            </ul>
          </div>
          <div class="others"></div>
        </div>
        <div class="hero_side col-lg-4">
          <div class="side_img">
           <a href="#">
            <?php dynamic_sidebar('sideimg') ?>
            <!-- <img src="./Assets/Images/Sidebar/Bangladesh-Directory.jpg" class="d-block w-100" alt=""> -->
          </a>
           

          </div>
          <div class="side_video">
            <h5>lorem</h5>
            <?php dynamic_sidebar('sidevideo')?>
            <!-- <iframe width="315" height="220" src="https://www.youtube.com/embed/B0FgrYBE4uY" title="মাননীয় প্রধানমন্ত্রী জননেত্রী শেখ হাসিনার নেতৃত্বে ডিজিটাল বাংলাদেশ এর এগিয়ে যাওয়ার ১২ বছর।" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
          </div>
        </div>
      </div>
    </section>
     <!-- Hero Part End -->
     <!-- footer part start -->
     <footer class="cont">
      <div class="row footer_main">
        <a href="#"><img src="./Assets/Images/Footer/download.png" alt=""></a>
      </div>
      <div class="row footer_bottom">
        <div class="col-lg-7 fb_left">
          <nav class="navbar navbar-expand-lg bg-light">
            <div class="container-fluid">
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">হোম</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">বাংলাদেশ সম্পর্কিত</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">ই-সেবাসমূহ</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">সেবাখাত</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#"> বৈদেশিক বিনিয়োগ</a>
                  </li>
                  
                </ul>
               
              </div>
            </div>
          </nav>
          <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২২-১০-৩০ ০৮:৩৫:০১</p>
        </div>
        <div class="col-lg-5 fb_right text-end">
          <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
          <a href="#"><img src="./Assets/Images/Footer/np-logo-set.png" alt=""></a>
        </div>
      </div>
     </footer>
     <!-- footer part end -->


    <?php wp_footer(); ?>
     <script src="./Assets/JS/bootstrap.bundle.min.js"></script>
     <section class="cont">
      <?php
      $x=10;
      while($x<=100){
        ($x%2==0)? print $x. '<br>' :'';
        $x=$x+5;
      }
      ?>
     </section>
</body>
</html>