<?php

/**
 * Proper way to enqueue scripts and styles.
 */
function wpdocs_theme_name_scripts() {
	wp_enqueue_style( 'style-name', get_stylesheet_uri() );
	wp_enqueue_style( 'style-name1',  get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
	wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );
register_sidebar([
	'name'           => 'BD Logo',
		'id'             => 'bdlogo',
		'description'    => '',
		
		'before_widget'  => '',
		'after_widget'   => '',
]);
add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
add_theme_support( 'post-thumbnails', array( 'post', 'movie' ) ); // Posts and Movies
if ( ! function_exists( 'mytheme_register_nav_menu' ) ) {

	function mytheme_register_nav_menu(){
		register_nav_menus( array(
	    	'primary_menu' => __( 'Primary Menu', 'text_domain' ),
	    	'footer_menu'  => __( 'Footer Menu', 'text_domain' ),
		) );
	}
	add_action( 'after_setup_theme', 'mytheme_register_nav_menu', 0 );
}
register_sidebar([
	'name'           => 'Hero Title',
		'id'             => 'herotitle',
		'description'    => '',
		
		'before_widget'  => '',
		'after_widget'   => '',
]);
register_sidebar([
	'name'           => 'Hero Image1',
		'id'             => 'heroimg1',
		'description'    => '',
		
		'before_widget'  => '',
		'after_widget'   => '',
]);
register_sidebar([
	'name'           => 'Hero Body1',
		'id'             => 'herobody1',
		'description'    => '',
		
		'before_widget'  => '',
		'after_widget'   => '',
]);

?>